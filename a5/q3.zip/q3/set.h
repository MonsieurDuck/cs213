#ifndef __set_h__
#define __set_h__

#include "integer.h"

void set_add(struct integer* integer);
void set_print();
void set_empty();

#endif
