#ifndef __helper_h__
#define __helper_h__

void helper_process_input(int argc, char** argv);

#endif
