#ifndef __stack_h__
#define __stack_h__

void stack_push(struct integer* integer);
void stack_pop_and_print();
int  stack_is_empty();

#endif
